

<?php $__env->startSection('content'); ?>
    <h1>Hello World</h1>

    <p>
        This view is loaded from module: <?php echo config('areamodule.name'); ?>

    </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('areamodule::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\aplus\store\Modules/AreaModule\Resources/views/index.blade.php ENDPATH**/ ?>