<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ProductModule\\Providers\\ProductModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ProductModule\\Providers\\ProductModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);