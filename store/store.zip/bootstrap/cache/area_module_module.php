<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AreaModule\\Providers\\AreaModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AreaModule\\Providers\\AreaModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);