<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\UiModule\\Providers\\UiModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\UiModule\\Providers\\UiModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);