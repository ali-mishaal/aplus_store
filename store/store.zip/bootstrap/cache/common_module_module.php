<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CommonModule\\Providers\\CommonModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CommonModule\\Providers\\CommonModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);