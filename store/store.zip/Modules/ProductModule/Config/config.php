<?php

return [
    'name' => 'ProductModule'
];
