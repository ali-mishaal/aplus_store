<?php

return [
    'name' => 'UiModule'
];
