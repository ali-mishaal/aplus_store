<?php

return [
    'name' => 'AreaModule'
];
