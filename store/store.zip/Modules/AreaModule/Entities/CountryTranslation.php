<?php

namespace Modules\AreaModule\Entities;

use Illuminate\Database\Eloquent\Model;

class CountryTranslation extends Model
{
    protected $fillable = ['name'];
    public $timestamps = false;
}
